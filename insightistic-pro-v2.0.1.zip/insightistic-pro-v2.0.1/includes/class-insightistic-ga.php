<?php
/**
 * Google Analytics 4 Data API class.
 *
 * @package Insightistic_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Insightistic_GA
 * Handles GA4 Data API requests with extended metrics.
 */
class Insightistic_GA {

	/**
	 * Register AJAX hooks.
	 */
	public function init() {
		add_action( 'wp_ajax_insightistic_get_data',        array( $this, 'ajax_get_data' ) );
		add_action( 'wp_ajax_insightistic_test_connection',  array( $this, 'ajax_test_connection' ) );
	}

	/* ------------------------------------------------------------------ */
	/* AJAX Handlers                                                        */
	/* ------------------------------------------------------------------ */

	/**
	 * Main data AJAX handler.
	 */
	public function ajax_get_data() {
		check_ajax_referer( 'insightistic_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'insightistic' ) );
		}

		$days        = min( max( intval( $_POST['days'] ?? 28 ), 1 ), 365 );
		$property_id = get_option( 'insightistic_pro_property_id' );

		if ( ! $property_id ) {
			wp_send_json_error( __( 'GA4 Property ID is not configured. Please visit Settings.', 'insightistic' ) );
		}

		// Check transient cache (15-minute TTL).
		$cache_key = 'insightistic_data_' . $days . '_' . md5( $property_id );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			wp_send_json_success( $cached );
		}

		$token = Insightistic_Auth::get_token( 'https://www.googleapis.com/auth/analytics.readonly', 'ga4' );
		if ( is_wp_error( $token ) ) {
			wp_send_json_error( $token->get_error_message() );
		}

		$end_date   = gmdate( 'Y-m-d' );
		$start_date = gmdate( 'Y-m-d', strtotime( "-{$days} days" ) );
		$prev_end   = gmdate( 'Y-m-d', strtotime( '-' . ( $days + 1 ) . ' days' ) );
		$prev_start = gmdate( 'Y-m-d', strtotime( '-' . ( $days * 2 ) . ' days' ) );

		// Run all reports.
		$attribution  = $this->get_attribution_report( $property_id, $token, $start_date, $end_date );
		if ( is_wp_error( $attribution ) ) {
			wp_send_json_error( $attribution->get_error_message() );
		}

		$time_series = $this->get_time_series( $property_id, $token, $start_date, $end_date );
		$overview    = $this->get_overview( $property_id, $token, $start_date, $end_date, $prev_start, $prev_end );
		$countries   = $this->get_countries( $property_id, $token, $start_date, $end_date, $prev_start, $prev_end );
		$pages       = $this->get_top_pages( $property_id, $token, $start_date, $end_date, $prev_start, $prev_end );
		$channels    = $this->get_traffic_channels( $property_id, $token, $start_date, $end_date, $prev_start, $prev_end );
		$top_posts   = $this->get_top_posts( $property_id, $token, $start_date, $end_date );

		$structured = $this->build_structured_data( $attribution );

		$result = array(
			'html'            => $this->render_attribution_table( $attribution ),
			'chartData'       => $time_series,
			'overview'        => $overview,
			'countries'       => $countries,
			'pages'           => $pages,
			'channels'        => $channels,
			'top_posts'       => $top_posts,
			'structured_data' => $structured,
		);

		set_transient( $cache_key, $result, 15 * MINUTE_IN_SECONDS );
		wp_send_json_success( $result );
	}

	/**
	 * Test GA4 connection AJAX handler.
	 */
	public function ajax_test_connection() {
		check_ajax_referer( 'insightistic_pro_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'insightistic' ) );
		}

		delete_transient( 'insightistic_pro_access_token_ga4' );

		$token = Insightistic_Auth::get_token( 'https://www.googleapis.com/auth/analytics.readonly', 'ga4' );
		if ( is_wp_error( $token ) ) {
			wp_send_json_error( $token->get_error_message() );
		}

		$property_id = get_option( 'insightistic_pro_property_id' );
		$url         = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
		$body        = array(
			'dateRanges' => array( array( 'startDate' => '7daysAgo', 'endDate' => 'today' ) ),
			'metrics'    => array( array( 'name' => 'sessions' ) ),
			'limit'      => 1,
		);

		$response = $this->api_request( $url, $body, $token );
		if ( is_wp_error( $response ) ) {
			wp_send_json_error( $response->get_error_message() );
		}

		wp_send_json_success( __( 'Connection successful! Your GA4 property is accessible.', 'insightistic' ) );
	}

	/* ------------------------------------------------------------------ */
	/* GA4 Report Methods                                                   */
	/* ------------------------------------------------------------------ */

	/**
	 * Get source/medium attribution report.
	 */
	private function get_attribution_report( $property_id, $token, $start, $end ) {
		$url  = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
		$body = array(
			'dateRanges' => array( array( 'startDate' => $start, 'endDate' => $end ) ),
			'dimensions' => array(
				array( 'name' => 'sessionSource' ),
				array( 'name' => 'sessionMedium' ),
			),
			'metrics'    => array(
				array( 'name' => 'sessions' ),
				array( 'name' => 'totalRevenue' ),
				array( 'name' => 'transactions' ),
				array( 'name' => 'purchasers' ),
				array( 'name' => 'averagePurchaseRevenue' ),
			),
			'orderBys'   => array(
				array( 'metric' => array( 'metricName' => 'sessions' ), 'desc' => true ),
			),
			'limit'      => 50,
		);

		$data = $this->api_request( $url, $body, $token );

		// Fallback without ecommerce metrics.
		if ( is_wp_error( $data ) || isset( $data['error'] ) ) {
			$body['metrics'] = array(
				array( 'name' => 'sessions' ),
				array( 'name' => 'totalRevenue' ),
				array( 'name' => 'transactions' ),
			);
			$data            = $this->api_request( $url, $body, $token );
			if ( ! is_wp_error( $data ) && ! isset( $data['error'] ) ) {
				$data['basic_metrics'] = true;
			}
		}

		if ( is_wp_error( $data ) ) {
			return $data;
		}
		if ( isset( $data['error'] ) ) {
			return new WP_Error( 'ga_error', $data['error']['message'] );
		}
		return $data;
	}

	/**
	 * Get daily time series data.
	 */
	private function get_time_series( $property_id, $token, $start, $end ) {
		$url  = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
		$body = array(
			'dateRanges' => array( array( 'startDate' => $start, 'endDate' => $end ) ),
			'dimensions' => array( array( 'name' => 'date' ) ),
			'metrics'    => array(
				array( 'name' => 'sessions' ),
				array( 'name' => 'totalRevenue' ),
				array( 'name' => 'activeUsers' ),
			),
			'orderBys'   => array(
				array( 'dimension' => array( 'dimensionName' => 'date' ) ),
			),
		);

		$data = $this->api_request( $url, $body, $token );
		if ( is_wp_error( $data ) || ! isset( $data['rows'] ) ) {
			return null;
		}

		$labels   = array();
		$sessions = array();
		$revenue  = array();
		$users    = array();

		foreach ( $data['rows'] as $row ) {
			$date_raw   = $row['dimensionValues'][0]['value'];
			$labels[]   = gmdate( 'M j', mktime( 0, 0, 0, substr( $date_raw, 4, 2 ), substr( $date_raw, 6, 2 ), substr( $date_raw, 0, 4 ) ) );
			$sessions[] = intval( $row['metricValues'][0]['value'] );
			$revenue[]  = round( floatval( $row['metricValues'][1]['value'] ), 2 );
			$users[]    = intval( $row['metricValues'][2]['value'] );
		}

		return compact( 'labels', 'sessions', 'revenue', 'users' );
	}

	/**
	 * Get extended overview stats with period comparison.
	 */
	private function get_overview( $property_id, $token, $start, $end, $prev_start, $prev_end ) {
		$url  = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
		$body = array(
			'dateRanges' => array(
				array( 'startDate' => $start,      'endDate' => $end,      'name' => 'current' ),
				array( 'startDate' => $prev_start, 'endDate' => $prev_end, 'name' => 'previous' ),
			),
			'metrics'    => array(
				array( 'name' => 'sessions' ),
				array( 'name' => 'totalUsers' ),
				array( 'name' => 'totalRevenue' ),
				array( 'name' => 'transactions' ),
				array( 'name' => 'screenPageViews' ),
				array( 'name' => 'averageSessionDuration' ),
				array( 'name' => 'bounceRate' ),
				array( 'name' => 'newUsers' ),
			),
		);

		$data = $this->api_request( $url, $body, $token );
		if ( is_wp_error( $data ) || ! isset( $data['totals'] ) ) {
			return null;
		}

		$cur  = $data['totals'][0]['metricValues'];
		$prev = $data['totals'][1]['metricValues'];

		$cur_new      = floatval( $cur[7]['value'] );
		$cur_total    = floatval( $cur[1]['value'] );
		$return_ratio = $cur_total > 0 ? round( ( ( $cur_total - $cur_new ) / $cur_total ) * 100, 1 ) : 0;
		$new_ratio    = $cur_total > 0 ? round( ( $cur_new / $cur_total ) * 100, 1 ) : 0;

		// Format avg session duration as m:ss.
		$avg_dur_sec = floatval( $cur[5]['value'] );
		$dur_min     = floor( $avg_dur_sec / 60 );
		$dur_sec     = str_pad( (int) ( $avg_dur_sec % 60 ), 2, '0', STR_PAD_LEFT );

		$prev_dur_sec = floatval( $prev[5]['value'] );

		return array(
			'sessions'     => array(
				'value'  => intval( $cur[0]['value'] ),
				'change' => $this->percent_change( floatval( $prev[0]['value'] ), floatval( $cur[0]['value'] ) ),
			),
			'unique_users' => array(
				'value'  => intval( $cur[1]['value'] ),
				'change' => $this->percent_change( floatval( $prev[1]['value'] ), floatval( $cur[1]['value'] ) ),
			),
			'revenue'      => array(
				'value'  => round( floatval( $cur[2]['value'] ), 2 ),
				'change' => $this->percent_change( floatval( $prev[2]['value'] ), floatval( $cur[2]['value'] ) ),
			),
			'transactions' => array(
				'value'  => intval( $cur[3]['value'] ),
				'change' => $this->percent_change( floatval( $prev[3]['value'] ), floatval( $cur[3]['value'] ) ),
			),
			'pageviews'    => array(
				'value'  => intval( $cur[4]['value'] ),
				'change' => $this->percent_change( floatval( $prev[4]['value'] ), floatval( $cur[4]['value'] ) ),
			),
			'avg_duration' => array(
				'value'       => $dur_min . ':' . $dur_sec,
				'value_raw'   => $avg_dur_sec,
				'change'      => $this->percent_change( $prev_dur_sec, $avg_dur_sec ),
			),
			'bounce_rate'  => array(
				'value'  => round( floatval( $cur[6]['value'] ) * 100, 1 ),
				'change' => $this->percent_change( floatval( $prev[6]['value'] ), floatval( $cur[6]['value'] ) ),
			),
			'new_vs_return' => array(
				'new_pct'     => $new_ratio,
				'return_pct'  => $return_ratio,
				'new_count'   => intval( $cur_new ),
				'total_count' => intval( $cur_total ),
			),
		);
	}

	/**
	 * Get top 5 countries with comparison.
	 */
	private function get_countries( $property_id, $token, $start, $end, $prev_start, $prev_end ) {
		$url  = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
		$body = array(
			'dateRanges' => array(
				array( 'startDate' => $start,      'endDate' => $end,      'name' => 'current' ),
				array( 'startDate' => $prev_start, 'endDate' => $prev_end, 'name' => 'previous' ),
			),
			'dimensions' => array( array( 'name' => 'country' ) ),
			'metrics'    => array( array( 'name' => 'sessions' ) ),
			'orderBys'   => array(
				array( 'metric' => array( 'metricName' => 'sessions' ), 'desc' => true ),
			),
			'limit'      => 5,
		);

		$data = $this->api_request( $url, $body, $token );
		if ( is_wp_error( $data ) || ! isset( $data['rows'] ) ) {
			return array();
		}

		$total_cur = 0;
		$rows_raw  = array();
		foreach ( $data['rows'] as $row ) {
			$cur_val    = intval( $row['metricValues'][0]['value'] );
			$prev_val   = intval( $row['metricValues'][1]['value'] ?? 0 );
			$total_cur += $cur_val;
			$rows_raw[] = array(
				'country' => $row['dimensionValues'][0]['value'],
				'current' => $cur_val,
				'prev'    => $prev_val,
			);
		}

		$result = array();
		foreach ( $rows_raw as $r ) {
			$result[] = array(
				'country'  => $r['country'],
				'sessions' => $r['current'],
				'share'    => $total_cur > 0 ? round( ( $r['current'] / $total_cur ) * 100, 1 ) : 0,
				'change'   => $this->percent_change( $r['prev'], $r['current'] ),
			);
		}
		return $result;
	}

	/**
	 * Get top 5 pages with comparison.
	 */
	private function get_top_pages( $property_id, $token, $start, $end, $prev_start, $prev_end ) {
		$url  = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
		$body = array(
			'dateRanges' => array(
				array( 'startDate' => $start,      'endDate' => $end,      'name' => 'current' ),
				array( 'startDate' => $prev_start, 'endDate' => $prev_end, 'name' => 'previous' ),
			),
			'dimensions' => array(
				array( 'name' => 'pageTitle' ),
				array( 'name' => 'pagePath' ),
			),
			'metrics'    => array(
				array( 'name' => 'screenPageViews' ),
				array( 'name' => 'bounceRate' ),
				array( 'name' => 'averageSessionDuration' ),
			),
			'orderBys'   => array(
				array( 'metric' => array( 'metricName' => 'screenPageViews' ), 'desc' => true ),
			),
			'limit'      => 5,
		);

		$data = $this->api_request( $url, $body, $token );
		if ( is_wp_error( $data ) || ! isset( $data['rows'] ) ) {
			return array();
		}

		$total_cur = 0;
		$rows_raw  = array();
		foreach ( $data['rows'] as $row ) {
			$cur_val    = intval( $row['metricValues'][0]['value'] );
			$prev_val   = intval( $row['metricValues'][1]['value'] ?? 0 );
			$total_cur += $cur_val;
			$rows_raw[] = array(
				'title'       => $row['dimensionValues'][0]['value'],
				'path'        => $row['dimensionValues'][1]['value'],
				'current'     => $cur_val,
				'prev'        => $prev_val,
				'bounce_rate' => round( floatval( $row['metricValues'][0]['value'] ) * 100, 1 ),
				'avg_time'    => floatval( $row['metricValues'][2]['value'] ),
			);
		}

		$result = array();
		foreach ( $rows_raw as $r ) {
			$avg_sec = $r['avg_time'];
			$result[] = array(
				'title'      => $r['title'],
				'path'       => $r['path'],
				'views'      => $r['current'],
				'share'      => $total_cur > 0 ? round( ( $r['current'] / $total_cur ) * 100, 1 ) : 0,
				'change'     => $this->percent_change( $r['prev'], $r['current'] ),
				'bounce'     => $r['bounce_rate'],
				'avg_time'   => floor( $avg_sec / 60 ) . ':' . str_pad( (int) ( $avg_sec % 60 ), 2, '0', STR_PAD_LEFT ),
			);
		}
		return $result;
	}

	/**
	 * Get traffic by channel group.
	 */
	private function get_traffic_channels( $property_id, $token, $start, $end, $prev_start, $prev_end ) {
		$url  = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
		$body = array(
			'dateRanges' => array(
				array( 'startDate' => $start,      'endDate' => $end,      'name' => 'current' ),
				array( 'startDate' => $prev_start, 'endDate' => $prev_end, 'name' => 'previous' ),
			),
			'dimensions' => array( array( 'name' => 'sessionDefaultChannelGroup' ) ),
			'metrics'    => array(
				array( 'name' => 'sessions' ),
				array( 'name' => 'totalUsers' ),
				array( 'name' => 'bounceRate' ),
			),
			'orderBys'   => array(
				array( 'metric' => array( 'metricName' => 'sessions' ), 'desc' => true ),
			),
			'limit'      => 10,
		);

		$data = $this->api_request( $url, $body, $token );
		if ( is_wp_error( $data ) || ! isset( $data['rows'] ) ) {
			return array();
		}

		$total_cur = 0;
		$rows_raw  = array();
		foreach ( $data['rows'] as $row ) {
			$cur_val    = intval( $row['metricValues'][0]['value'] );
			$prev_val   = intval( $row['metricValues'][1]['value'] ?? 0 );
			$total_cur += $cur_val;
			$rows_raw[] = array(
				'channel' => $row['dimensionValues'][0]['value'],
				'current' => $cur_val,
				'users'   => intval( $row['metricValues'][1]['value'] ),
				'bounce'  => round( floatval( $row['metricValues'][2]['value'] ) * 100, 1 ),
				'prev'    => $prev_val,
			);
		}

		$result = array();
		foreach ( $rows_raw as $r ) {
			$result[] = array(
				'channel' => $r['channel'],
				'sessions' => $r['current'],
				'users'   => $r['users'],
				'bounce'  => $r['bounce'],
				'share'   => $total_cur > 0 ? round( ( $r['current'] / $total_cur ) * 100, 1 ) : 0,
				'change'  => $this->percent_change( $r['prev'], $r['current'] ),
			);
		}
		return $result;
	}

	/**
	 * Get top blog posts (filters by common blog URL patterns).
	 */
	private function get_top_posts( $property_id, $token, $start, $end ) {
		$url  = "https://analyticsdata.googleapis.com/v1beta/properties/{$property_id}:runReport";
		$body = array(
			'dateRanges' => array( array( 'startDate' => $start, 'endDate' => $end ) ),
			'dimensions' => array(
				array( 'name' => 'pageTitle' ),
				array( 'name' => 'pagePath' ),
			),
			'metrics'    => array(
				array( 'name' => 'screenPageViews' ),
				array( 'name' => 'averageSessionDuration' ),
			),
			'dimensionFilter' => array(
				'orGroup' => array(
					'expressions' => array(
						array(
							'filter' => array(
								'fieldName'    => 'pagePath',
								'stringFilter' => array( 'matchType' => 'CONTAINS', 'value' => '/blog/' ),
							),
						),
						array(
							'filter' => array(
								'fieldName'    => 'pagePath',
								'stringFilter' => array( 'matchType' => 'CONTAINS', 'value' => '/post/' ),
							),
						),
						array(
							'filter' => array(
								'fieldName'    => 'pagePath',
								'stringFilter' => array( 'matchType' => 'CONTAINS', 'value' => '/article/' ),
							),
						),
						array(
							'filter' => array(
								'fieldName'    => 'pagePath',
								'stringFilter' => array( 'matchType' => 'CONTAINS', 'value' => '/news/' ),
							),
						),
					),
				),
			),
			'orderBys'   => array(
				array( 'metric' => array( 'metricName' => 'screenPageViews' ), 'desc' => true ),
			),
			'limit'      => 5,
		);

		$data = $this->api_request( $url, $body, $token );
		if ( is_wp_error( $data ) || ! isset( $data['rows'] ) ) {
			return array();
		}

		$result = array();
		foreach ( $data['rows'] as $row ) {
			$avg_sec  = floatval( $row['metricValues'][1]['value'] );
			$result[] = array(
				'title'    => $row['dimensionValues'][0]['value'],
				'path'     => $row['dimensionValues'][1]['value'],
				'views'    => intval( $row['metricValues'][0]['value'] ),
				'avg_time' => floor( $avg_sec / 60 ) . ':' . str_pad( (int) ( $avg_sec % 60 ), 2, '0', STR_PAD_LEFT ),
			);
		}
		return $result;
	}

	/* ------------------------------------------------------------------ */
	/* Table Renderer                                                       */
	/* ------------------------------------------------------------------ */

	/**
	 * Build structured data for AI consumption.
	 */
	private function build_structured_data( $data ) {
		$structured = array(
			'channels' => array(),
			'totals'   => array( 'visitors' => 0, 'revenue' => 0, 'transactions' => 0 ),
		);
		if ( empty( $data['rows'] ) ) {
			return $structured;
		}
		foreach ( $data['rows'] as $row ) {
			$v  = intval( $row['metricValues'][0]['value'] );
			$r  = floatval( $row['metricValues'][1]['value'] );
			$tx = intval( $row['metricValues'][2]['value'] );
			$ch = array(
				'source'          => $row['dimensionValues'][0]['value'],
				'medium'          => $row['dimensionValues'][1]['value'],
				'visitors'        => $v,
				'revenue'         => $r,
				'transactions'    => $tx,
				'conversion_rate' => $v > 0 ? round( ( $tx / $v ) * 100, 2 ) : 0,
			);
			$structured['channels'][]               = $ch;
			$structured['totals']['visitors']        += $v;
			$structured['totals']['revenue']         += $r;
			$structured['totals']['transactions']    += $tx;
		}
		return $structured;
	}

	/**
	 * Render the attribution data table HTML.
	 */
	private function render_attribution_table( $data ) {
		$basic       = ! empty( $data['basic_metrics'] );
		$source_data = array();

		if ( ! empty( $data['rows'] ) ) {
			foreach ( $data['rows'] as $row ) {
				$v      = intval( $row['metricValues'][0]['value'] );
				$rev    = floatval( $row['metricValues'][1]['value'] );
				$tx     = intval( $row['metricValues'][2]['value'] );
				$buyers = $basic ? $tx : intval( $row['metricValues'][3]['value'] ?? $tx );
				$aov    = $basic ? ( $tx > 0 ? $rev / $tx : 0 ) : floatval( $row['metricValues'][4]['value'] ?? 0 );
				$source_data[] = array(
					'source'  => $row['dimensionValues'][0]['value'],
					'medium'  => $row['dimensionValues'][1]['value'],
					'sessions' => $v,
					'revenue' => $rev,
					'tx'      => $tx,
					'buyers'  => $buyers,
					'rpv'     => $v > 0 ? $rev / $v : 0,
					'conv'    => $buyers > 0 && $v > 0 ? ( $buyers / $v ) * 100 : 0,
					'aov'     => $aov,
				);
			}
		}

		$total_rev = array_sum( array_column( $source_data, 'revenue' ) );
		$has_rev   = $total_rev > 0;
		$avg_rpv   = count( $source_data ) ? array_sum( array_column( $source_data, 'rpv' ) ) / count( $source_data ) : 0;
		$avg_conv  = count( $source_data ) ? array_sum( array_column( $source_data, 'conv' ) ) / count( $source_data ) : 0;

		ob_start();
		?>
		<div class="isp-table-wrap">
			<table class="isp-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Source / Medium', 'insightistic' ); ?></th>
						<th><?php esc_html_e( 'Sessions', 'insightistic' ); ?></th>
						<?php if ( $has_rev ) : ?>
						<th><?php esc_html_e( 'Revenue', 'insightistic' ); ?></th>
						<th><?php esc_html_e( 'Revenue %', 'insightistic' ); ?></th>
						<?php endif; ?>
						<th><?php esc_html_e( 'Transactions', 'insightistic' ); ?></th>
						<?php if ( $has_rev ) : ?>
						<th><?php esc_html_e( 'Rev/Session', 'insightistic' ); ?></th>
						<th><?php esc_html_e( 'Conv. Rate', 'insightistic' ); ?></th>
						<?php endif; ?>
					</tr>
				</thead>
				<tbody>
				<?php if ( empty( $source_data ) ) : ?>
					<tr><td colspan="<?php echo $has_rev ? 7 : 3; ?>" class="isp-no-data"><?php esc_html_e( 'No data found for this period.', 'insightistic' ); ?></td></tr>
				<?php else :
					$totals = array( 'sessions' => 0, 'revenue' => 0, 'tx' => 0, 'buyers' => 0 );
					foreach ( $source_data as $row ) :
						$rev_pct    = $has_rev && $total_rev > 0 ? ( $row['revenue'] / $total_rev ) * 100 : 0;
						$rpv_class  = $this->perf_class( $row['rpv'], $avg_rpv );
						$conv_class = $this->perf_class( $row['conv'], $avg_conv );
						$totals['sessions'] += $row['sessions'];
						$totals['revenue']  += $row['revenue'];
						$totals['tx']       += $row['tx'];
						$totals['buyers']   += $row['buyers'];
						?>
						<tr>
							<td>
								<span class="isp-src-icon"><?php echo esc_html( $this->source_icon( $row['source'], $row['medium'] ) ); ?></span>
								<span class="isp-src-label"><?php echo esc_html( $row['source'] . ' / ' . $row['medium'] ); ?></span>
							</td>
							<td><?php echo esc_html( number_format( $row['sessions'] ) ); ?></td>
							<?php if ( $has_rev ) : ?>
							<td>$<?php echo esc_html( number_format( $row['revenue'], 2 ) ); ?></td>
							<td>
								<div class="isp-rev-bar">
									<div class="isp-rev-bar-fill" style="width:<?php echo esc_attr( min( $rev_pct, 100 ) ); ?>%"></div>
									<span><?php echo esc_html( number_format( $rev_pct, 1 ) ); ?>%</span>
								</div>
							</td>
							<?php endif; ?>
							<td><?php echo esc_html( number_format( $row['tx'] ) ); ?></td>
							<?php if ( $has_rev ) : ?>
							<td>
								<span class="isp-perf <?php echo esc_attr( $rpv_class ); ?>"></span>
								$<?php echo esc_html( number_format( $row['rpv'], 2 ) ); ?>
							</td>
							<td>
								<span class="isp-perf <?php echo esc_attr( $conv_class ); ?>"></span>
								<?php echo esc_html( number_format( $row['conv'], 2 ) ); ?>%
							</td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
					<tr class="isp-totals-row">
						<td><strong><?php esc_html_e( 'Total', 'insightistic' ); ?></strong></td>
						<td><strong><?php echo esc_html( number_format( $totals['sessions'] ) ); ?></strong></td>
						<?php if ( $has_rev ) : ?>
						<td><strong>$<?php echo esc_html( number_format( $totals['revenue'], 2 ) ); ?></strong></td>
						<td><strong>100%</strong></td>
						<?php endif; ?>
						<td><strong><?php echo esc_html( number_format( $totals['tx'] ) ); ?></strong></td>
						<?php if ( $has_rev ) : ?>
						<td><strong>$<?php echo esc_html( number_format( $totals['sessions'] > 0 ? $totals['revenue'] / $totals['sessions'] : 0, 2 ) ); ?></strong></td>
						<td><strong><?php echo esc_html( number_format( $totals['sessions'] > 0 ? ( $totals['buyers'] / $totals['sessions'] ) * 100 : 0, 2 ) ); ?>%</strong></td>
						<?php endif; ?>
					</tr>
				<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
		return ob_get_clean();
	}

	/* ------------------------------------------------------------------ */
	/* Helpers                                                             */
	/* ------------------------------------------------------------------ */

	/**
	 * Make an authenticated POST request to the GA4 Data API.
	 */
	private function api_request( $url, $body, $token ) {
		$response = wp_remote_post(
			$url,
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
				'timeout' => 20,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return json_decode( wp_remote_retrieve_body( $response ), true );
	}

	/**
	 * Calculate percent change between two values.
	 */
	private function percent_change( $old, $new ) {
		if ( 0 === $old || 0.0 === $old ) {
			return $new > 0 ? 100 : 0;
		}
		return round( ( ( $new - $old ) / $old ) * 100, 1 );
	}

	/**
	 * Return CSS class for performance indicator.
	 */
	private function perf_class( $value, $average ) {
		if ( 0 == $average ) {
			return 'isp-perf-neutral';
		}
		if ( $value >= $average * 1.2 ) {
			return 'isp-perf-high';
		}
		if ( $value <= $average * 0.8 ) {
			return 'isp-perf-low';
		}
		return 'isp-perf-medium';
	}

	/**
	 * Return an emoji icon for a traffic source.
	 */
	private function source_icon( $source, $medium ) {
		$s = strtolower( $source );
		$m = strtolower( $medium );

		if ( strpos( $m, 'cpc' ) !== false || strpos( $m, 'paid' ) !== false ) {
			return '💰';
		}
		if ( strpos( $m, 'email' ) !== false ) {
			return '✉️';
		}
		if ( strpos( $m, 'social' ) !== false || in_array( $s, array( 'facebook', 'instagram', 'twitter', 'tiktok', 'linkedin', 'pinterest', 'youtube' ), true ) ) {
			return '📲';
		}
		if ( 'organic' === $m || in_array( $s, array( 'google', 'bing', 'yahoo', 'duckduckgo', 'baidu' ), true ) ) {
			return '🔍';
		}
		if ( 'referral' === $m ) {
			return '🔗';
		}
		if ( '(direct)' === $s ) {
			return '🎯';
		}
		return '🌐';
	}
}
